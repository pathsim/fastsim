# Hand-maintained shim module. Docstrings mirrored from pathsim with
# example imports rewritten to fastsim.
# fastsim.subsystem — Drop-in replacement for pathsim.subsystem

from fastsim.blocks._shim import _ShimBlock


class Interface(_ShimBlock):
    """
    Bare-bone block that serves as a data interface for the 'Subsystem' class.

    It works like this:

    - Internal blocks of the subsystem are connected to the inputs and outputs
      of this Interface block via the internal connections.
    - It behaves like a normal block (inherits the main 'Block' class methods).
    - It implements some special methods to get and set the inputs and outputs
      of the blocks, that are used to translate between the internal blocks of the
      subsystem and the inputs and outputs of the subsystem.
    - Handles data transfer to and from the internal subsystem blocks
      to and from the inputs and outputs of the subsystem.
    """
    _factory_name = "Interface"
    _param_defaults = {}

    def __init__(self):
        super().__init__()
        self._shim_init({})


class Subsystem(_ShimBlock):
    """
    Subsystem class that holds its own blocks and connecions and
    can natively interface with the main simulation loop.

    IO interface is realized by a special 'Interface' block, that has extra
    methods for setting and getting inputs and outputs and serves
    as the interface of the internal blocks to the outside.

    The subsystem doesnt use its 'inputs' and 'outputs' dicts directly.
    It exclusively handles data transfer via the 'Interface' block.

    This class can be used just like any other block during the simulation,
    since it implements the required methods 'update' for the fixed-point
    iteration (resolving algebraic loops with instant time blocks),
    the 'step' method that performs timestepping (especially for dynamic
    blocks with internal states) and the 'solve' method for solving the
    implicit update equation for implicit solvers.


    Example
    -------
    This is how we can wrap up multiple blocks within a subsystem.
    In this case vanderpol system built from discrete components
    instead of using an ODE block (in practice you should use
    a monolithic ODE whenever possible due to performance).

    .. code-block:: python

        from fastsim import Subsystem, Interface, Connection
        from fastsim.blocks import Integrator, Function

        #van der Pol parameter
        mu = 1000

        #blocks in the subsystem
        If = Interface() # this is the interface to the outside
        I1 = Integrator(2)
        I2 = Integrator(0)
        Fn = Function(lambda x1, x2: mu*(1 - x1**2)*x2 - x1)

        sub_blocks = [If, I1, I2, Fn]

        #connections in the subsystem
        sub_connections = [
            Connection(I2, I1, Fn[1], If[1]),
            Connection(I1, Fn, If),
            Connection(Fn, I2)
            ]

        #the subsystem acts just like a normal block
        vdp = Subsystem(sub_blocks, sub_connections)


    Parameters
    ----------
    blocks : list[Block] | None
        internal blocks of the subsystem
    connections : list[Connection] | None
        internal connections of the subsystem
    events : list[Event] | None
    tolerance_fpi : float
        absolute tolerance for convergence of algebraic loops
        default see ´SIM_TOLERANCE_FPI´ in ´_constants.py´
    iterations_max : int
        maximum allowed number of iterations for algebraic loop
        solver, default see ´SIM_ITERATIONS_MAX´ in ´_constants.py´

    Attributes
    ----------
    interface : Interface
        internal interface block for data transfer to the outside
    graph : Graph
        internal graph representation for fast system funcion
        evluations using DAG with algebraic depths
    boosters : None | list[ConnectionBooster]
        list of boosters (fixed point accelerators) that wrap
        algebraic loop closing connections assembled from the
        system graph
    """
    _factory_name = "Subsystem"
    _param_defaults = {"blocks": None, "connections": None, "events": None, "iterations_max": 200}

    def __init__(self, blocks=None, connections=None, events=None,
                 iterations_max=200, **kwargs):
        super().__init__()
        params = {
            "blocks": blocks if blocks is not None else [],
            "connections": connections if connections is not None else [],
            "events": events,
            "iterations_max": iterations_max,
        }
        params.update(kwargs)
        self._shim_init(params)
