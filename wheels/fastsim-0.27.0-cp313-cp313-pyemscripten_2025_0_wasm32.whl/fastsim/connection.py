# Hand-maintained shim module. Docstrings mirrored from pathsim with
# example imports rewritten to fastsim.
# fastsim.connection — Drop-in replacement for pathsim.connection

from fastsim._fastsim import Connection as _Connection


class Connection(_Connection):
    """
    Class to handle input-output relations of blocks by connecting them (directed graph)
    and transfering data from the output port of the source block to the input port of
    the target block.

    The default ports for connection are (0) -> (0), since these are the default inputs
    that are used in the SISO blocks.

    Examples
    --------
    Lets assume we have some blocks

    .. code-block:: python

        from fastsim.blocks import Integrator, Amplifier, Scope

        B1 = Integrator()
        B2 = Amplifier(2.0)
        B3 = Scope()


    that we want to connect. We initialize a 'Connection' with the blocks directly
    as the arguments if we want to connect the default ports (0) -> (0)

    .. code-block:: python

        from fastsim import Connection

        C = Connection(B1, B2)


    which is a connection from block 'B1' to 'B2'. If we want to explicitly declare
    the input and output ports we can do that by utilizing the '__getitem__' method
    of the blocks

    .. code-block:: python

        C = Connection(B1[0], B2[0])


    which is exactly the default port setup. Connecting output port (1) of 'B1' to
    the default input port (0) of 'B2' do

    .. code-block:: python

        C = Connection(B1[1], B2[0])


    or just

    .. code-block:: python

        C = Connection(B1[1], B2).


    The 'Connection' class also supports multiple targets for a single source.
    This is specified by just adding more blocks with their respective ports into
    the constructor like this:

    .. code-block:: python

        C = Connection(B1, B2[0], B2[1], B3)


    The port definitions follow the same structure as for single target connections.

    'self'-connections also work without a problem. This is useful for modeling direct
    feedback of a block to itself.

    Port definitions support slicing. This enables direct MIMO connections. For example
    connecting ports 0, 1, 2 of 'B1' to ports 1, 2, 3 of 'B2' works like this:

    .. code-block:: python

        C = Connection(B1[0:2], B2[1:3])


    Port definitions also support lists and tuples of 'int'. For example the slice
    above is identical to this:

    .. code-block:: python

        C = Connection(B1[0, 1], B2[1, 2])


    Or to be more programmatic about it, like this:

    .. code-block:: python

        prts_1 = [0, 1]
        prts_2 = [1, 2]

        C = Connection(B1[prts_1], B2[prts_2])


    Another way to define the ports is by using strings. Some blocks have internal
    aliases for the ports that can be used instead of the integer port indices to
    define the connections (or access the port data):

    .. code-block:: python

        C = Connection(B1["out"], B2["in"])


    Or mixed with integer port indices:

    .. code-block:: python

        C = Connection(B1["out"], B2["in"])


    Parameters
    ----------
    source : PortReference, Block
        source block and optional source output port
    targets : tuple[PortReference], tuple[Block]
        target blocks and optional target input ports


    Attributes
    ----------
    _active : bool
        flag to set 'Connection' as active or inactive
    """
